Command-line program to download videos from YouTube.com and other video sites


